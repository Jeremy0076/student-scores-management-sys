/*
Navicat MySQL Data Transfer

Source Server         : 本地mysql
Source Server Version : 50726
Source Host           : localhost:3306
Source Database       : chengji

Target Server Type    : MYSQL
Target Server Version : 50726
File Encoding         : 65001

Date: 2020-12-25 20:23:20
*/

SET FOREIGN_KEY_CHECKS=0;
SET NAMES utf8mb4;

-- ----------------------------
-- Table structure for admininfo
-- ----------------------------
DROP TABLE IF EXISTS `admininfo`;
CREATE TABLE `admininfo`  (
  `id` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `password` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of admininfo
-- ----------------------------
INSERT INTO `admininfo` VALUES ('10000', '123456');

-- ----------------------------
-- Table structure for courseinfo
-- ----------------------------
DROP TABLE IF EXISTS `courseinfo`;
CREATE TABLE `courseinfo` (
  `courseId` varchar(10) NOT NULL,
  `courseName` varchar(30) NOT NULL,
  PRIMARY KEY (`courseId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of courseinfo
-- ----------------------------
INSERT INTO `courseinfo` VALUES ('A', '数据库');
INSERT INTO `courseinfo` VALUES ('B', '操作系统');
INSERT INTO `courseinfo` VALUES ('C', '线性代数');
INSERT INTO `courseinfo` VALUES ('D', '数据结构');


-- ----------------------------
-- Table structure for grades
-- ----------------------------
DROP TABLE IF EXISTS `grades`;
CREATE TABLE `grades` (
  `stuId` varchar(11) NOT NULL,
  `courseId` varchar(10) NOT NULL,
  `score` int(4) NOT NULL,
  PRIMARY KEY (`stuId`,`courseId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of grades
-- ----------------------------
INSERT INTO `grades` VALUES ('20183220092', 'A', '100');
INSERT INTO `grades` VALUES ('20183220092', 'D', '100');
INSERT INTO `grades` VALUES ('20183210076', 'A', '100');
INSERT INTO `grades` VALUES ('20183210076', 'D', '100');
INSERT INTO `grades` VALUES ('20183220148', 'A', '100');
INSERT INTO `grades` VALUES ('20183220148', 'B', '95');
INSERT INTO `grades` VALUES ('20183220001', 'B', '80');
INSERT INTO `grades` VALUES ('20183220001', 'D', '95');
INSERT INTO `grades` VALUES ('20183220002', 'B', '75');
INSERT INTO `grades` VALUES ('20183220002', 'D', '90');
INSERT INTO `grades` VALUES ('20183220003', 'B', '85');
INSERT INTO `grades` VALUES ('20183220003', 'D', '87');
INSERT INTO `grades` VALUES ('20183220004', 'A', '83');
INSERT INTO `grades` VALUES ('20183220004', 'C', '100');
INSERT INTO `grades` VALUES ('20183220005', 'B', '90');
INSERT INTO `grades` VALUES ('20183220005', 'C', '70');
INSERT INTO `grades` VALUES ('20183220006', 'B', '85');
INSERT INTO `grades` VALUES ('20183220006', 'C', '85');
INSERT INTO `grades` VALUES ('20183220007', 'A', '80');
INSERT INTO `grades` VALUES ('20183220007', 'C', '75');
INSERT INTO `grades` VALUES ('20183220008', 'B', '95');
INSERT INTO `grades` VALUES ('20183220008', 'C', '90');
INSERT INTO `grades` VALUES ('20183220009', 'A', '92');
INSERT INTO `grades` VALUES ('20183220009', 'C', '95');


-- ----------------------------
-- Table structure for selectcourse
-- ----------------------------
DROP TABLE IF EXISTS `selectcourse`;
CREATE TABLE `selectcourse` (
  `stuId` varchar(11) NOT NULL,
  `teaId` varchar(10) NOT NULL,
  `courseId` varchar(10) NOT NULL,
  PRIMARY KEY (`stuId`,`teaId`,`courseId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of selectcourse
-- ----------------------------
INSERT INTO `selectcourse` VALUES ('20183220092', '10001', 'A');
INSERT INTO `selectcourse` VALUES ('20183220092', '10004', 'D');
INSERT INTO `selectcourse` VALUES ('20183210076', '10001', 'A');
INSERT INTO `selectcourse` VALUES ('20183210076', '10004', 'D');
INSERT INTO `selectcourse` VALUES ('20183220148', '10001', 'A');
INSERT INTO `selectcourse` VALUES ('20183220148', '10004', 'B');
INSERT INTO `selectcourse` VALUES ('20183220001', '10002', 'B');
INSERT INTO `selectcourse` VALUES ('20183220001', '10004', 'D');
INSERT INTO `selectcourse` VALUES ('20183220002', '10002', 'B');
INSERT INTO `selectcourse` VALUES ('20183220002', '10004', 'D');
INSERT INTO `selectcourse` VALUES ('20183220003', '10002', 'B');
INSERT INTO `selectcourse` VALUES ('20183220003', '10004', 'D');
INSERT INTO `selectcourse` VALUES ('20183220004', '10001', 'A');
INSERT INTO `selectcourse` VALUES ('20183220004', '10003', 'C');
INSERT INTO `selectcourse` VALUES ('20183220005', '10002', 'B');
INSERT INTO `selectcourse` VALUES ('20183220005', '10003', 'C');
INSERT INTO `selectcourse` VALUES ('20183220006', '10002', 'B');
INSERT INTO `selectcourse` VALUES ('20183220006', '10003', 'C');
INSERT INTO `selectcourse` VALUES ('20183220007', '10001', 'A');
INSERT INTO `selectcourse` VALUES ('20183220007', '10003', 'C');
INSERT INTO `selectcourse` VALUES ('20183220008', '10002', 'B');
INSERT INTO `selectcourse` VALUES ('20183220008', '10003', 'C');
INSERT INTO `selectcourse` VALUES ('20183220009', '10001', 'A');
INSERT INTO `selectcourse` VALUES ('20183220009', '10003', 'C');

-- ----------------------------
-- Table structure for stuinfo
-- ----------------------------
DROP TABLE IF EXISTS `stuinfo`;
CREATE TABLE `stuinfo` (
  `stuId` varchar(11) NOT NULL,
  `stuPaw` varchar(10) NOT NULL,
  `stuName` varchar(20) NOT NULL,
  `stuClass` varchar(2) NOT NULL,
  `stuSex` char(2) NOT NULL,
  PRIMARY KEY (`stuId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of stuinfo
-- ----------------------------
INSERT INTO `stuinfo` VALUES ('20183220092', '123456', '陈镜濠', '1', '男');
INSERT INTO `stuinfo` VALUES ('20183210076', '123456', '张俊濠', '1', '男');
INSERT INTO `stuinfo` VALUES ('20183220148', '123456', '周华锐', '1', '男');
INSERT INTO `stuinfo` VALUES ('20183220001', '123456', '扈三娘', '1', '女');
INSERT INTO `stuinfo` VALUES ('20183220002', '123456', '林冲', '1', '男');
INSERT INTO `stuinfo` VALUES ('20183220003', '123456', '吴用', '1', '男');
INSERT INTO `stuinfo` VALUES ('20183220004', '123456', '武松', '2', '男');
INSERT INTO `stuinfo` VALUES ('20183220005', '123456', '公孙胜', '2', '男');
INSERT INTO `stuinfo` VALUES ('20183220006', '123456', '孙二娘', '2', '女');
INSERT INTO `stuinfo` VALUES ('20183220007', '123456', '鲁智深', '2', '男');
INSERT INTO `stuinfo` VALUES ('20183220008', '123456', '宋江', '2', '男');
INSERT INTO `stuinfo` VALUES ('20183220009', '123456', '顾大嫂', '2', '女');

-- ----------------------------
-- Table structure for teainfo
-- ----------------------------
DROP TABLE IF EXISTS `teainfo`;
CREATE TABLE `teainfo` (
  `teaId` varchar(11) NOT NULL,
  `teaPaw` varchar(10) NOT NULL,
  `teaName` varchar(20) NOT NULL,
  `teaSex` varchar(2) NOT NULL,
  PRIMARY KEY (`teaId`) 
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of teainfo
-- ----------------------------
INSERT INTO `teainfo` VALUES ('10001', '123456', '郭云镝', '男');
INSERT INTO `teainfo` VALUES ('10002', '123456', '张俊杰', '男');
INSERT INTO `teainfo` VALUES ('10003', '123456', '何俊峰', '男');
INSERT INTO `teainfo` VALUES ('10004', '123456', '张红平', '女');
