<?php
  // Define database connection constants
  define('DB_HOST', '127.0.0.1');
  define('DB_USER', 'root');//数据库用户名
  define('DB_PASSWORD', '123456');//数据库密码
  define('DB_NAME', 'chengji');//成绩管理数据库名称
?> 
